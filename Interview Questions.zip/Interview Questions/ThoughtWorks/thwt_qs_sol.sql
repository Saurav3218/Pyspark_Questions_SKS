from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, window
from pyspark.sql.types import StructType, StringType, TimestampType

# 1️⃣ Create SparkSession with Kafka support
spark = SparkSession.builder \
    .appName("BlueCarsWindowedCount") \
    .getOrCreate()

# 2️⃣ Define schema for Kafka message (assuming JSON payload)
# Example Kafka message: {"car_id": "123", "color": "blue", "event_time": "2024-09-24T12:30:00Z"}
schema = StructType() \
    .add("car_id", StringType()) \
    .add("color", StringType()) \
    .add("event_time", TimestampType())

# 3️⃣ Read stream from Kafka
df_raw = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "cars_topic") \
    .option("startingOffsets", "latest") \
    .load()

# 4️⃣ Parse Kafka value (JSON payload)
df_parsed = df_raw.select(
    from_json(col("value").cast("string"), schema).alias("data")
).select("data.*")

# 5️⃣ Filter only blue cars
df_blue = df_parsed.filter(col("color") == "blue")

# 6️⃣ Apply window function
# - 2 minute sliding window
# - Trigger output every 5 minutes
df_windowed = df_blue.groupBy(
    window(col("event_time"), "2 minutes", "5 minutes")
).count()

# 7️⃣ Write output to console (for demo)
query = df_windowed.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", False) \
    .trigger(processingTime="5 minutes") \
    .start()

query.awaitTermination()

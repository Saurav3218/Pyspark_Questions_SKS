from pyspark.sql import SparkSession
from pyspark.sql.functions import col, countDistinct, count

# Start Spark session
spark = SparkSession.builder \
    .appName("Activity Data Report") \
    .getOrCreate()

# Load dataset
df = spark.read
    .option("header", "true")        # if your CSV has a header row
    .option("inferSchema", "true")   # to automatically infer column types
    .option("sep", " ")              # space as delimiter
    .csv("activity_data.csv")

# Filter out incomplete data (drop rows with nulls in critical fields)
clean_df = df.dropna(subset=["Date", "User_id", "Activity_type"])

# ---------------------------
# 1. Basic Statistics
# ---------------------------
# Record count
record_count = clean_df.count()
print("Total Records:", record_count)

# Number of users per day
users_per_day = clean_df.groupBy("Date").agg(countDistinct("User_id").alias("unique_users"))
users_per_day.show()

# ---------------------------
# 2. Activity Summary
# ---------------------------
# Count of each activity done by users per day
activity_summary = (
    clean_df.groupBy("Date", "User_id", "Activity_type")
    .agg(count("*").alias("activity_count"))
)

activity_summary.show()

# ---------------------------
# 3. Save in Parquet format
# ---------------------------
activity_summary.write.mode("overwrite").parquet("output/activity_summary_parquet")


====================================================================================================================================

# Filter only login/logout activities
df = df.filter(col("activity_type").isin("login", "logout"))

# Convert timestamp column to proper timestamp type
df = df.withColumn("timestamp", F.to_timestamp("timestamp"))

# Create window to order events by timestamp per user
windowSpec = Window.partitionBy("user_id").orderBy("timestamp")

# Lead to find next activity
df = df.withColumn("next_activity", F.lead("activity_type").over(windowSpec)) \
       .withColumn("next_timestamp", F.lead("timestamp").over(windowSpec))

# Keep only login → logout pairs
sessions = df.filter((col("activity_type") == "login") & (col("next_activity") == "logout"))

# Calculate session duration in seconds
sessions = sessions.withColumn(
    "session_duration",
    unix_timestamp("next_timestamp") - unix_timestamp("timestamp")
)

# Add week number
sessions = sessions.withColumn("week_number", weekofyear("timestamp"))

# Total time spent per user per week
weekly_usage = sessions.groupBy("user_id", "week_number") \
                       .agg(spark_sum("session_duration").alias("total_time_spent_seconds"))

weekly_usage.show(20, truncate=False)


====================================================================================================================================

def compress_string(s: str) -> str:
    if not s:
        return s
    
    compressed = []
    count = 1
    
    # Traverse the string
    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            count += 1
        else:
            compressed.append(s[i - 1] + str(count))
            count = 1
    
    # Add last character group
    compressed.append(s[-1] + str(count))
    
    compressed_str = "".join(compressed)
    
    # Return the smaller one
    return compressed_str if len(compressed_str) < len(s) else s


# Example test
print(compress_string("aabcccccaaa"))  # Output: "a2b1c5a3"
print(compress_string("abc"))          # Output: "abc" (since compressed is not smaller)

====================================================================================================================================

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Start Spark session (if not already running)
spark = SparkSession.builder.appName("Task-3 NoShipment and PaymentNoConfirm").getOrCreate()

# Assuming df is your cleaned dataframe with columns: user_id, activity_type, timestamp
# Example: df = spark.read.csv("activity_data.csv", header=True, inferSchema=True)

# Users who added to cart
addcart_users = df.filter(col("activity_type") == "addcart").select("user_id").distinct()

# Users who made payment
payment_users = df.filter(col("activity_type") == "pagepayment").select("user_id").distinct()

# Users who got shipment confirmation
shipment_users = df.filter(col("activity_type") == "shipmentconfirmation").select("user_id").distinct()

# -----------------------
# 1. NoShipment = addcart but not payment
# -----------------------
noshipment = addcart_users.join(payment_users, on="user_id", how="left_anti")

# -----------------------
# 2. PaymentNoConfirm = payment but not shipment
# -----------------------
payment_no_confirm = payment_users.join(shipment_users, on="user_id", how="left_anti")

# Show results
print("Users who added to cart but never paid (NoShipment):")
noshipment.show()

print("Users who paid but no shipment confirmation (PaymentNoConfirm):")
payment_no_confirm.show()

====================================================================================================================================


Write a SQL query to generate a report of customers with number of orders and payeestthly

2 3 (based on order purchase timestamp). Derive customer loyalty score based on tatal payment, alatalo

orders.

And derive a new field Customer value type High/Medium/Low 4

if value per order is <100-Low, 100-500: Medium and 500 is high value customer. Its a enthly repart 5

6 order year order month

total orders loyalty Lov ent Loyalty High cut Loyaltyd

7 Write your query herd
ChatGPT said:

Got it 👍. You want a SQL query that:

Generates a monthly report (order_year, order_month).

Groups data by customer.

Shows:

total_orders

total_payment

loyalty_score (you can define it, e.g., total_payment / total_orders).

Categorizes each customer into High / Medium / Low value based on average order value.

Here’s a generic SQL query you can adapt (works in most SQL engines like PostgreSQL, MySQL, SQL Server, or SAP HANA with slight tweaks):

SELECT
    c.customer_id,
    EXTRACT(YEAR FROM o.order_timestamp) AS order_year,
    EXTRACT(MONTH FROM o.order_timestamp) AS order_month,
    COUNT(o.order_id) AS total_orders,
    SUM(o.payment_amount) AS total_payment,
    -- loyalty_score: defined as total payment * total orders (you can change as needed)
    SUM(o.payment_amount) / NULLIF(COUNT(o.order_id), 0) AS loyalty_score,
    CASE 
        WHEN (SUM(o.payment_amount) / NULLIF(COUNT(o.order_id), 0)) < 100 
            THEN 'Low'
        WHEN (SUM(o.payment_amount) / NULLIF(COUNT(o.order_id), 0)) BETWEEN 100 AND 500 
            THEN 'Medium'
        ELSE 'High'
    END AS customer_value_type
FROM
    customers c
JOIN
    orders o ON c.customer_id = o.customer_id
GROUP BY
    c.customer_id,
    EXTRACT(YEAR FROM o.order_timestamp),
    EXTRACT(MONTH FROM o.order_timestamp)
ORDER BY
    order_year,
    order_month,
    c.customer_id;

🔎 Explanation:

EXTRACT(YEAR|MONTH) → splits orders into months.

COUNT(o.order_id) → total orders.

SUM(o.payment_amount) → total payment per customer/month.

loyalty_score → here I used Avg Order Value (SUM / COUNT). You can redefine (e.g., SUM * COUNT).

CASE → defines High / Medium / Low based on avg order value thresholds you gave:

<100 → Low

100–500 → Medium

>500 → High.
id	name	department	salary
1	Alice	HR		50000
2	Bob		IT		60000
3	Charlie	IT		70000
4	Diana	HR		55000
 
Need to find the average salary per department and then list employees who earn above their department's average.

with dept_avg as(
select department, avg(salary) as avg_dept_salary from employee
group by department
),
employee as(
select name, department, salary from employee
) 
select e.name as name, e.id as id from employee e inner join dept_avg d
on d.department = e.department and e.salary > d.avg_dept_salary

val emp_df = spark.read.format("csv").option("inferSchema", "true").option("header","true").load("employee.csv")

val dept_avg_df = emp_df.groupBy(col("department")).agg(avg(col("salary").alias("avg_dept_salary"))

val emp_sal_df = emp_df.select("name", "department", "salary")

val result_df = emp_sal_df.join(dept_avg_df, emp_sal_df["department"] == dept_avg_df["dept_avg_df"]).drop(dept_avg_df["dept_avg_df"])
						  .filter(emp_sal_df.salary > dept_avg_df.salary)
						  .select(emp_sal_df.name, emp_sal_df.id)
						  


input:
 
id	sale_date	amount
1	2024-01-01	100
2	2024-01-02	150
3	2024-01-03	120
4	2024-01-04	200
 
Output:
 
id	sale_date	amount	colA 	ColB
1	2024-01-01	100		NULL	150
2	2024-01-02	150		100		120
3	2024-01-03	120		150		200
4	2024-01-04	200		120		NULL

lag and lead functions


select id, sale_date, amount, lag(amount) over(order by sale_date) as colA,
lead(amount) over(order by sale_date) as colB
from input_table;



Read a file from local, check data is available or not, if available make a df using pandas, if not raise a error message..
after reading into df count the strings available in a file.


def file_count_check(spark,path):
	flag = 0
	with f as f.open():
		str = f.readLine()
		try:
			if len(str) > 0:
				print("Data is available")
				flag = 1
		catch:
			  print("data not found" + e.getMessage())
    if flag == 1:
    	df = spark.read.format("text").option("inferSchema","true").load("path")
    	split_df = df.withColumn("value", split(col("value"), " "))
    	explode_df = split_df.withColumn("value", explode(col("value")))
    	grouped_df = explode_df.groupBy(col("value")).agg(count("value").alias("word_count"))
    return grouped_df


df = file_count_check("/tmp/sample.txt")
df.show()






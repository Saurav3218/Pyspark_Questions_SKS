You are given a CSV file Trades.csv (Columns: date, ticker, price, volume) attached here. 
Write PySpark code to:
Read the csv from an S3 location into a PySpark data frame
Create two new columns
a) rolling 15 days Average Daily Dollar Volume per ticker
b) rolling 15 days cumulative forward returns for each ticker 
c) Write this dataset as a multi-part Parquet back to S3 (partitioned by date)
3. Plot the Portfolio Cumulative Return and Drawdown. Assume the portfolio is constructed by assigning equal weights to each ticker 


#Reading csv data from S3
df = spark.read.option("inferSchema", "true").option("header", "true").load("s3a://trade/trades.csv")

date		ticker	price	volume
11/1/2024	OOGL	171.29	31796.48
11/4/2024	OOGL	169.24	21492.74
11/5/2024	OOGL	169.74	18242.051
11/6/2024	OOGL	176.51	33695.539
11/7/2024	OOGL	180.75	25352.939
11/8/2024	OOGL	178.35	22006.18
11/11/2024	OOGL	180.35	17450.35
11/12/2024	OOGL	181.62	25134.91
11/13/2024	OOGL	178.88	23184
11/14/2024	OOGL	175.58	31007.461
11/15/2024	OOGL	172.49	32504.65
11/18/2024	OOGL	175.3	20206.609
11/19/2024	OOGL	178.12	23434.93
11/20/2024	OOGL	175.98	18997.109
11/21/2024	OOGL	167.63	59734.379

assuming it its for daily volume rolling 15 days average and per day we have only 1 volume sale

#Creating 2 columns for rolling window
windowSpec = Window.partitionBy(col("ticker")).orderBy(col("date"))
df_rolling_avg_per_ticker = df.withColumn("rolling_15days_avg_volume", avg(volume).over(windowSpec).rowsBetween(unboundedPreceding 14 and current_row)) #a
							  .withColumn("rolling_15days_cumm_returns", sum(price).over(windowSpec).rowsBetween(unboundedPreceding and unboundedFollowing))  #b


#write to S3 in parquet partitioned by Date and repartitioning by 10 as multi part parquet files are required
df_rolling_avg_per_ticker.repartition(10).write
	.partitionBy("date")
	.option("mode", "overWrite")
	.parquet("s3a://trade/trade_results/)



Plot the Portfolio Cumulative Return and Drawdown. Assume the portfolio is constructed by assigning equal weights to each ticker 

not worked on plotting the data. but we can use matpotlib or use databricks visualtion tools like graph to do the same.
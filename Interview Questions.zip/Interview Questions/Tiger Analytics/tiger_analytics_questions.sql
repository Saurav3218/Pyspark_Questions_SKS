1. what is liquid clustering and how does it differ from zorder?
2. what is surrogate key and how do you define? where do you use it ?(bronze/silver/gold)
3. how do you stream your data on bronze layer ? (Autoloader)
4. what is scd type 1 and scd type 2?
5. how do you read metdata driven architecture? say suppose 100 tables are there at source, how do you read only required 20 tables?
6. how do you define watermarks?
7. explain your medallion architecture pipeline.
8. how do you seperate HR rows to be seen by HR team only - column level masking
9. what is data governance and how do you use it with unity catalog?
10. how to link databricks with adls gen2 - adb connector with external creds
11. what is open delta sharing - to transfer data from databricks to outside?
12. how do you trigger you job at gold layer on every hour's end? -- trigger(processingTime='360000secs')
13. PySpark Optimization done?
14. What are Logic Apps?
15. What is Log Analytics Workspace? Why it's used?
16. what is data skewness and how do you know by Saprk UI that there is data skewness is there?

SQL Questions-- 
You have two tables: Employee : emp_id , emp_name
Salary: emp_id, salary_date, salary
Q. Write an SQL query to calculate the percentage hike in salary for each employee compared to their previous salary record.
Input Table

salary table                                         employee table
+--------+-------------+--------+                    +--------+----------+
| emp_id | salary_date | salary |                             | emp_id | emp_name |
+--------+-------------+--------+                    +--------+----------+
| 1     | 2024-01-01 | 50000 |                     | 1     | Alice   |
| 1     | 2025-01-01 | 60000 |                     | 2     | Bob     |
| 2     | 2024-06-01 | 45000 |                     | 3     | Carol   |
| 2     | 2025-01-01 | 49500 |                     +--------+----------+
| 3     | 2024-03-01 | 70000 |                     
| 3     | 2025-01-01 | 73500 |                     
             

Expected Output:-

+--------+----------+-------------+--------+-------------+--------+--------------+
| emp_id | emp_name | prev_salary | p_date | curr_salary | c_date | hike_percent |
+--------+----------+-------------+--------+-------------+--------+--------------+
| 1     | Alice   | 50000      | 2024-01-01 | 60000 | 2025-01-01 | 20.00    |
| 2     | Bob     | 45000      | 2024-06-01 | 49500 | 2025-01-01 | 10.00    |
| 3     | Carol   | 70000      | 2024-03-01 | 73500 | 2025-01-01 | 5.00     |



with joined_cte as(
select e.emp_id as emp_id, e.emp_name as emp_name, s.salary, s.salary_date
from employee e inne join salary s on e.emp_id = s.emp_id
),
agg_cte as(
select emp_id, emp_name, salary as prev_salary, lead(salary) over(partition by emp_id order by salary_date) as curr_salary,
salary_date as p_date, lead(salary_date) over(partition by emp_id order by salary_date) as c_date
from joined_cte
),
select emp_id, emp_name, prev_salary, p_date, curr_salary, c_date, 100*((curr_salary-prev_salary)/prev_salary) as hike_percent
from agg_cte order by emp_id;
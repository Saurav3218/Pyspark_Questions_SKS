1. Leader Element (A leader element in an array (or list) is an element that is greater than all the elements to its right)

Input:  [16, 17, 4, 3, 5, 2]
Output: [17, 5, 2]


def find_leaders(arr):
    n = len(arr)
    leaders = []
    max_from_right = arr[-1]   # Last element is always a leader
    leaders.append(max_from_right)

    # Traverse from right to left
    for i in range(n-2, -1, -1):
        if arr[i] > max_from_right:
            leaders.append(arr[i])
            max_from_right = arr[i]

    return leaders[::-1]   # Reverse to maintain original order


# Example usage
arr = [16, 17, 4, 3, 5, 2]
print(find_leaders(arr))


2. Sort an array without sort().

3. Lakehouse medallion architecture advantages

4. Lakehouse medallion architecture demerits

5. snowflake vs star schema -- whne to use and benefits?

6. explain data pipeline